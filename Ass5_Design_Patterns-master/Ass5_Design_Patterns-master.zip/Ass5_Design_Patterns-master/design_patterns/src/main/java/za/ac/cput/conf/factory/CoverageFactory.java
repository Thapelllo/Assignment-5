package za.ac.cput.conf.factory;

import za.ac.cput.domain.Coverage;

/**
 * Created by LILO on 2016/04/08.
 */
public interface CoverageFactory {
    Coverage createCoverage();
}
